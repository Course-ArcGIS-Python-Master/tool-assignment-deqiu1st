# NRS568 Python for GIS
# Tool Assignment : Flooded Structure Assessment Tool
# Author: Deky

# Description:
# This tool is built to analyze structures / buildings that have the potential to be submerged by flooding based on
# FEMA flood area data in South Kingstown, and to determine the density of submerged buildings in the form of clusters / fishnet (/ sq km)
# which can then be used to determine priority locations mitigation efforts. The structures / building being focus are
# residential, commercial and public facilities. Where the flood area used here are area that have 0.2% annual chance
# flood hazard.

# Input files:
# 1. Structures.shp (structures data from rigis.org)
# 2. S_FLD_HAZ_AR.shp (flood area from FEMA)
# 3. Town.shp (town boundary from rigis.shp)

# Output files:
# 1. flooded structure (*.shp)
# 2. flooded structure summary (*.xls) which contains with number of flooded and not flooded
# 3. flooded structure cluster (*.shp) which contains with number/density of structure per sq km

#####

# Importing the packages
import os, arcpy, glob
arcpy.CheckOutExtension("spatial")
arcpy.env.overwriteOutput = True
Delete_temp_files = True

# ADJUST/CHANGE THIS "input_directory" TO YOUR WORKING DIRECTORY PATH
input_directory = "C:\Users\deky\PycharmProjects\Python4GIS\ToolAssignmentDeky"

# Creating folder for output and temporary files
if not os.path.exists(os.path.join(input_directory, "temp")):
    os.mkdir(os.path.join(input_directory, "temp"))
if not os.path.exists(os.path.join(input_directory, "output")):
    os.mkdir(os.path.join(input_directory, "output"))

# Dictionary of the structure type that being analyze
dictStructures = {"R": "Residential_structure", "C": "Commercial_structure", "P": "Public_structure" }

# Begin looping for each structure type
for i,val in dictStructures.items():
    print "\n Processing flood assessment for " + val + "..."

    # 0. Set the workspace
    arcpy.env.workspace = input_directory
    print "Workspace: " + arcpy.env.workspace

    # 1. Preparing structure data
    print "1. Preparing " + val + " data..."
    # Process: Select
    structureSelectInput = "structures.shp"
    structureSelectOutput = "temp/" + val + "_select.shp"
    where_clause1 = '"TYPE" LIKE ' + "'" + i + "%'"
    arcpy.Select_analysis(structureSelectInput, structureSelectOutput, where_clause1)
    print " - structure selected"
    # Process: Dissolve
    structureDissolveInput = structureSelectOutput
    structureDissolveOutput = "temp/" + val + "_dissolve.shp"
    dissolveField = "TOWNCODE"
    arcpy.Dissolve_management(structureDissolveInput, structureDissolveOutput, dissolveField, "", "SINGLE_PART", "DISSOLVE_LINES")
    print " - structure dissolved"

    # 2. Preparing flood data
    print "2. Preparing flood data..."
    # Process: Project
    floodInput = "S_FLD_HAZ_AR.shp"
    floodProjectOutput = "temp/floodRISPF.shp"
    out_coordinate_system = arcpy.SpatialReference('NAD 1983 StatePlane Rhode Island FIPS 3800 (US Feet)')
    if arcpy.Exists(floodProjectOutput):
        print " - projected flood data already exist"
    else:
        arcpy.Project_management(floodInput, floodProjectOutput, out_coordinate_system)
        print " - flood data projected"
    # Process: Dissolve
    floodDissolveInput = floodProjectOutput
    floodDissolveOutput = "temp/floodRISPF_dissolve.shp"
    dissolveField = "ZONE_SUBTY"
    if arcpy.Exists(floodDissolveOutput):
        print " - dissolved flood data already exist"
    else:
        arcpy.Dissolve_management(floodDissolveInput, floodDissolveOutput, dissolveField, "", "MULTI_PART", "DISSOLVE_LINES")
        print " - floodRISPF dissolved"
    # Process: Select
    floodSelectInput = floodDissolveOutput
    floodSelectOutput = "temp/floodRISPF_select.shp"
    flood_where_clause = '"ZONE_SUBTY" = ' + "'0.2 PCT ANNUAL CHANCE FLOOD HAZARD'"
    if arcpy.Exists(floodSelectOutput):
        print " - selected flood data already exist"
    else:
        arcpy.Select_analysis(floodSelectInput, floodSelectOutput,flood_where_clause)
        print " - flood data selected"

    # 3. Assessing flooded structures
    print "3. Assessing flooded structure..."
    output_path = input_directory + "/output/"
    if not os.path.exists(os.path.join(output_path, val)):
        os.mkdir(os.path.join(output_path, val))
    # Process: Identity
    structure_asInput = structureDissolveOutput
    flood_asIdentity = floodSelectOutput
    outputIdentity = output_path + val + "/flooded_" + val + ".shp"
    arcpy.Identity_analysis(structure_asInput, flood_asIdentity, outputIdentity)
    print " --> flooded " + val + " data generated \n file path: " + outputIdentity

    # 4. Tidy up and summarize the flooded structures data
    print "4. Tidy up and summarize the flooded structures data"
    # Process: Add Field
    flood_AddField = outputIdentity
    fieldNameAdd1 = "flood_stat"
    fieldTypeAdd1 = "TEXT"
    fieldLengthAdd1 = "15"
    fieldNullableAdd1 = "NULLABLE"
    fieldRequiredAdd1 = "NON_REQUIRED"
    arcpy.AddField_management(flood_AddField, fieldNameAdd1, fieldTypeAdd1, "", "", fieldLengthAdd1, "", fieldNullableAdd1,
                              fieldRequiredAdd1, "")
    print " - added flood_stat field "
    # Process: Calculate Field
    floodCalculateTable = outputIdentity
    fieldNameCalculate1 = "flood_stat"
    expression1 = "value( !ZONE_SUBTY!)"
    codeblock1 = """
    
def value(text):
    if text == "0.2 PCT ANNUAL CHANCE FLOOD HAZARD":
        return "Flooded"
    else:
        return "Not Flooded" """

    arcpy.CalculateField_management(floodCalculateTable, fieldNameCalculate1, expression1,"PYTHON_9.3",codeblock1)
    print " - flood_stat calculated"
    # Process: Delete Field
    floodDeleteFieldInput = outputIdentity
    floodDroppedfield = ["FID_Commer", "TOWNCODE","FID_floodR", "ZONE_SUBTY"]
    arcpy.DeleteField_management(floodDeleteFieldInput, floodDroppedfield)
    print " - table cleaned out"
    # Process: Summary Statistics
    InputSum = outputIdentity
    outputSum = "temp/" + val + "_summary.dbf"
    statsField = [["flood_stat", "COUNT"]]
    casefield = "flood_stat"
    arcpy.Statistics_analysis(InputSum, outputSum, statsField, casefield)
    print " - table summarized"
    # Process: Export table to xls
    inputExport = outputSum
    outputExport = output_path + val + "/flooded_" + val + "_summary.xls"
    columnHeader = "NAME"
    domainSubtype = "CODE"
    arcpy.TableToExcel_conversion(inputExport,outputExport,columnHeader, domainSubtype)
    print " --> summary table generated \n file path: " + outputExport

    # 5. Assessing priority cluster (/sq Km)
    print "5. Assessing priority cluster by density (/sq Km)"
    # Process: Create Fishnet
    boundary = "Town.shp"
    desc = arcpy.Describe(boundary)
    arcpy.env.outputCoordinateSystem = arcpy.SpatialReference(102730)
    outputFishnet = "temp/" + val + "_Fishnet.shp"
    originCoordinate = "{0} {1}".format(desc.extent.XMin, desc.extent.YMin)
    yAxisCoordinate = "{0} {1}".format(desc.extent.XMin, desc.extent.YMax)
    cellSizeWidth = "3280.84"  # 3280.84 feet --> 1 km
    cellSizeHeight = "3280.84"
    numRows =  ""
    numColumns = ""
    oppositeCorner = "{0} {1}".format(desc.extent.XMax, desc.extent.YMax)
    labels = "NO_LABELS"
    templateExtent = "#"
    geometryType = "POLYGON"
    arcpy.CreateFishnet_management(outputFishnet, originCoordinate, yAxisCoordinate,
                                   cellSizeWidth, cellSizeHeight, numRows, numColumns,
                                   oppositeCorner, labels, templateExtent, geometryType)
    print " - Fishnet cluster created"
    # Process: Selected flooded structure only
    floodedStructureSelectInput = outputIdentity
    floodedStructureSelectOutput = "temp/Flooded_" + val + "_select.shp"
    where_clause2 = '"flood_stat" = ' + "'Flooded'"
    arcpy.Select_analysis(floodedStructureSelectInput, floodedStructureSelectOutput, where_clause2)
    print " - flooded structure selected"
    # Process: Spatial Join
    target_features = outputFishnet
    join_features = floodedStructureSelectOutput
    output_join = output_path + val + "/flooded_" + val + "_Cluster.shp"
    join_operation="JOIN_ONE_TO_ONE"
    join_type="KEEP_ALL"
    field_mapping=""
    match_option="INTERSECT"
    search_radius=""
    distance_field_name=""

    arcpy.SpatialJoin_analysis(target_features, join_features, output_join,
                               join_operation, join_type, field_mapping, match_option,
                               search_radius, distance_field_name)
    print " --> priority cluster generated \n file path: " + output_join

    # 6. Tidy up priority cluster data
    print "6. Tidy up priority cluster data"
    # Process: Add Field
    priorityCluster_AddField = output_join
    fieldNameAdd2 = "Num_struc"
    fieldTypeAdd2 = "DOUBLE"
    fieldLengthAdd2 = "5"
    fieldNullableAdd2 = "NULLABLE"
    fieldRequiredAdd2 = "NON_REQUIRED"
    arcpy.AddField_management(priorityCluster_AddField, fieldNameAdd2, fieldTypeAdd2, "", "", fieldLengthAdd2, "",
                              fieldNullableAdd2, fieldRequiredAdd2, "")
    print " - added num_structure field "
    # Process: Calculate Field
    priorityCalculateTable = output_join
    fieldNameCalculate2 = "Num_struc"
    expression2 = "!Join_Count!"
    arcpy.CalculateField_management(priorityCalculateTable, fieldNameCalculate2, expression2, "PYTHON_9.3")
    print " - num_structure calculated"
    # Process: Delete Field
    priorityDeleteFieldInput = output_join
    priorityDroppedfield = ["Join_Count", "TARGET_FID", "Id"]
    arcpy.DeleteField_management(priorityDeleteFieldInput, priorityDroppedfield)
    print " - table cleaned out"

# Deleting temporary files
if Delete_temp_files == True:
    arcpy.Delete_management(os.path.join(input_directory, "temp"))
    print "\n Temporary files deleted \n Process DONE!"








